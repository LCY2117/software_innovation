import React, { useState } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine,
} from "recharts";
import { ShieldCheck, TrendingDown, TrendingUp, CheckCircle2 } from "lucide-react";
import { demoData } from "../data/demoData";
import { C, DataCard, CardHeader, ModuleHeader, ProgressBar, SourceBadge } from "../components/shared";

export default function Module4() {
  const { performance, roi, materials } = demoData;
  const [activePerf, setActivePerf] = useState<"low_carbon_binder" | "roadbase_repair">("low_carbon_binder");

  // Strength chart data (low_carbon_binder has all three)
  const strengthData = [
    {
      day: "0d",
      低碳胶凝材料: 0,
      路基修复材料: 0,
    },
    {
      day: "3d",
      低碳胶凝材料: performance.low_carbon_binder.strength_mpa.d3,
      路基修复材料: null,
    },
    {
      day: "7d",
      低碳胶凝材料: performance.low_carbon_binder.strength_mpa.d7,
      路基修复材料: null,
    },
    {
      day: "28d",
      低碳胶凝材料: performance.low_carbon_binder.strength_mpa.d28,
      路基修复材料: performance.roadbase_repair.strength_mpa.d28,
    },
  ];

  const saving = roi.gross_saving;
  const savingPct = Math.round(((roi.traditional_cost_per_ton - roi.solution_cost_per_ton) / roi.traditional_cost_per_ton) * 100);

  return (
    <div>
      <ModuleHeader
        step={4}
        title="数字孪生 · 性能预测与经济价值核算"
        description="文献级强度曲线 · 合规认证 · 传统方案 vs 本方案 ROI 对比"
        accentColor={C.green}
        statusLabel="性能验证通过"
        statusColor={C.green}
      />

      {/* Top KPI Row */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "12px", marginBottom: "16px" }}>
        {[
          { label: "28d 抗压强度", value: "44.52", unit: "MPa", accent: C.green, sub: "低碳胶凝材料 · 文献数据" },
          { label: "单吨节省成本", value: `¥${roi.traditional_cost_per_ton - roi.solution_cost_per_ton}`, accent: C.cyan, sub: `降本 ${savingPct}%（${roi.traditional_cost_per_ton} → ${roi.solution_cost_per_ton}）` },
          { label: "总节省金额", value: `¥${(roi.gross_saving / 10000).toFixed(0)}万`, accent: C.amber, sub: `处理规模 ${demoData.batch.total_quantity_tons.toLocaleString()} 吨` },
          { label: "浸出检测", value: "全部达标", accent: C.green, sub: "HJ 557-2010 · 100% PASS" },
        ].map((item) => (
          <div
            key={item.label}
            style={{
              background: C.bgCard,
              border: `1px solid ${C.borderSubtle}`,
              borderRadius: "12px",
              padding: "16px",
              position: "relative",
              overflow: "hidden",
            }}
          >
            <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "2px", background: `linear-gradient(90deg, transparent, ${item.accent}, transparent)` }} />
            <div style={{ fontSize: "10px", fontWeight: 600, color: C.textMuted, textTransform: "uppercase", letterSpacing: "0.08em" }}>{item.label}</div>
            <div style={{ fontSize: "24px", fontWeight: 800, color: item.accent, marginTop: "4px", letterSpacing: "-0.02em" }}>{item.value}</div>
            {item.unit && <span style={{ fontSize: "12px", color: C.textMuted }}>{item.unit}</span>}
            <div style={{ fontSize: "11px", color: C.textMuted, marginTop: "4px" }}>{item.sub}</div>
          </div>
        ))}
      </div>

      {/* Main 2-col Grid */}
      <div style={{ display: "grid", gridTemplateColumns: "1.2fr 1fr", gap: "16px" }}>

        {/* Left: Strength Chart + Compliance */}
        <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
          <DataCard glowing accent={C.green}>
            <CardHeader
              title="强度发展曲线"
              subtitle="Compressive Strength Development (MPa)"
              accent={C.green}
              right={<SourceBadge type="literature" />}
            />
            <div style={{ padding: "8px 8px 0" }}>
              <ResponsiveContainer width="100%" height={260}>
                <LineChart data={strengthData} margin={{ top: 10, right: 20, left: 0, bottom: 10 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(6,182,212,0.08)" />
                  <XAxis dataKey="day" tick={{ fill: C.textMuted, fontSize: 11 }} axisLine={{ stroke: C.borderSubtle }} tickLine={false} />
                  <YAxis
                    tick={{ fill: C.textMuted, fontSize: 11 }}
                    axisLine={false}
                    tickLine={false}
                    tickFormatter={(v) => `${v}`}
                    label={{ value: "MPa", angle: -90, position: "insideLeft", fill: C.textMuted, fontSize: 11 }}
                  />
                  <Tooltip
                    contentStyle={{
                      background: C.bgCard,
                      border: `1px solid ${C.borderSubtle}`,
                      borderRadius: "8px",
                      fontSize: "12px",
                      color: C.textPrimary,
                    }}
                    formatter={(v: number | null) => v !== null ? [`${v} MPa`, ""] : ["待测", ""]}
                  />
                  <Legend
                    wrapperStyle={{ fontSize: "11px", color: C.textSecondary, paddingTop: "8px" }}
                  />
                  {/* Reference lines for strength milestones */}
                  <ReferenceLine y={42.5} stroke="rgba(245,158,11,0.5)" strokeDasharray="4 3" label={{ value: "P·O42.5 水泥参考", fill: C.amber, fontSize: 9, position: "right" }} />
                  <Line
                    type="monotone"
                    dataKey="低碳胶凝材料"
                    stroke={C.green}
                    strokeWidth={2.5}
                    dot={{ fill: C.green, r: 5, strokeWidth: 0 }}
                    activeDot={{ r: 7, fill: C.green }}
                    connectNulls={false}
                  />
                  <Line
                    type="monotone"
                    dataKey="路基修复材料"
                    stroke={C.blue}
                    strokeWidth={2}
                    strokeDasharray="5 3"
                    dot={{ fill: C.blue, r: 4, strokeWidth: 0 }}
                    activeDot={{ r: 6, fill: C.blue }}
                    connectNulls={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* Strength milestones */}
            <div style={{ padding: "0 16px 14px", display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "8px" }}>
              {[
                { day: "3d", value: "15.55 MPa", color: C.green, note: "早强达标" },
                { day: "7d", value: "27.44 MPa", color: C.green, note: "中期强度" },
                { day: "28d", value: "44.52 MPa", color: C.green, note: "超 P·O42.5 级" },
              ].map((item) => (
                <div key={item.day} style={{ padding: "8px", background: `${item.color}10`, border: `1px solid ${item.color}25`, borderRadius: "8px", textAlign: "center" }}>
                  <div style={{ fontSize: "11px", color: C.textMuted }}>{item.day}</div>
                  <div style={{ fontSize: "15px", fontWeight: 700, color: item.color }}>{item.value}</div>
                  <div style={{ fontSize: "10px", color: `${item.color}90` }}>{item.note}</div>
                </div>
              ))}
            </div>
          </DataCard>

          {/* Compliance Badges */}
          <DataCard>
            <CardHeader title="合规认证 · 标准徽章" subtitle="Compliance Certification" accent={C.cyan} />
            <div style={{ padding: "12px 16px", display: "flex", flexDirection: "column", gap: "8px" }}>
              {[
                {
                  badge: "HJ 557-2010",
                  name: "固体废物浸出毒性浸出方法 水平振荡法",
                  pass: true,
                  color: C.green,
                  detail: "所有材料路线均浸出达标",
                },
                {
                  badge: "JTG/T 3610-2019",
                  name: "公路路基施工技术规范",
                  pass: true,
                  color: C.blue,
                  detail: "低碳胶凝 & 路基修复材料适配",
                },
              ].map((std) => (
                <div
                  key={std.badge}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "12px",
                    padding: "10px 12px",
                    background: `${std.color}0c`,
                    border: `1px solid ${std.color}25`,
                    borderRadius: "8px",
                  }}
                >
                  <div
                    style={{
                      padding: "4px 10px",
                      background: `${std.color}20`,
                      border: `1px solid ${std.color}50`,
                      borderRadius: "6px",
                      fontSize: "11px",
                      fontWeight: 700,
                      color: std.color,
                      flexShrink: 0,
                    }}
                  >
                    {std.badge}
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: "12px", fontWeight: 600, color: C.textPrimary }}>{std.name}</div>
                    <div style={{ fontSize: "11px", color: C.textMuted, marginTop: "1px" }}>{std.detail}</div>
                  </div>
                  <CheckCircle2 size={18} color={C.green} />
                </div>
              ))}
            </div>
          </DataCard>
        </div>

        {/* Right: ROI */}
        <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
          {/* ROI Header Card */}
          <DataCard glowing accent={C.amber}>
            <CardHeader title="成本对比 · ROI 核算" subtitle="Traditional vs. AIizer Solution" accent={C.amber} right={<SourceBadge type={roi.source_type} />} />
            <div style={{ padding: "16px" }}>
              {/* Cost bars */}
              <div style={{ display: "flex", flexDirection: "column", gap: "12px", marginBottom: "16px" }}>
                <div>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "6px" }}>
                    <span style={{ fontSize: "12px", color: C.textMuted }}>传统处置方案</span>
                    <span style={{ fontSize: "13px", fontWeight: 700, color: C.red }}>¥{roi.traditional_cost_per_ton}/吨</span>
                  </div>
                  <div style={{ height: "10px", background: `${C.red}20`, borderRadius: "5px", overflow: "hidden" }}>
                    <div style={{ height: "100%", width: "100%", background: `linear-gradient(90deg, ${C.red}80, ${C.red})`, borderRadius: "5px" }} />
                  </div>
                  <div style={{ fontSize: "10px", color: C.textMuted, marginTop: "3px" }}>总费用 ¥{(roi.traditional_total_cost / 10000).toFixed(0)} 万</div>
                </div>

                <div>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "6px" }}>
                    <span style={{ fontSize: "12px", color: C.textMuted }}>本系统方案</span>
                    <span style={{ fontSize: "13px", fontWeight: 700, color: C.green }}>¥{roi.solution_cost_per_ton}/吨</span>
                  </div>
                  <div style={{ height: "10px", background: `${C.green}20`, borderRadius: "5px", overflow: "hidden" }}>
                    <div style={{ height: "100%", width: `${(roi.solution_cost_per_ton / roi.traditional_cost_per_ton) * 100}%`, background: `linear-gradient(90deg, ${C.green}80, ${C.green})`, borderRadius: "5px" }} />
                  </div>
                  <div style={{ fontSize: "10px", color: C.textMuted, marginTop: "3px" }}>总费用 ¥{(roi.solution_total_cost / 10000).toFixed(0)} 万</div>
                </div>
              </div>

              {/* Saving Highlight */}
              <div
                style={{
                  padding: "16px",
                  background: "linear-gradient(135deg, rgba(16,185,129,0.12), rgba(6,182,212,0.08))",
                  border: "1px solid rgba(16,185,129,0.35)",
                  borderRadius: "12px",
                  textAlign: "center",
                  marginBottom: "12px",
                }}
              >
                <div style={{ fontSize: "11px", color: C.textMuted, marginBottom: "4px" }}>综合节省金额</div>
                <div style={{ fontSize: "36px", fontWeight: 800, color: C.green, letterSpacing: "-0.02em" }}>
                  ¥{(saving / 10000).toFixed(0)}<span style={{ fontSize: "18px" }}>万</span>
                </div>
                <div style={{ fontSize: "12px", color: C.green, marginTop: "4px" }}>
                  降本 {savingPct}% · 处理 {demoData.batch.total_quantity_tons.toLocaleString()} 吨
                </div>
              </div>

              {/* Unit Price Components */}
              <div style={{ fontSize: "11px", fontWeight: 600, color: C.textMuted, marginBottom: "8px", textTransform: "uppercase", letterSpacing: "0.06em" }}>
                参考价格 (市场调研)
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "6px" }}>
                {[
                  { name: "42.5级水泥", price: roi.cement_price_cny_per_ton },
                  { name: "生石灰/熟石灰", price: roi.lime_price_cny_per_ton },
                  { name: "粉煤灰", price: roi.flyash_price_cny_per_ton },
                  { name: "运输成本", price: `${roi.transport_cost_per_ton_km}/吨·km` },
                ].map((item) => (
                  <div
                    key={item.name}
                    style={{
                      padding: "7px 10px",
                      background: C.bgCardHover,
                      border: `1px solid ${C.borderSubtle}`,
                      borderRadius: "6px",
                    }}
                  >
                    <div style={{ fontSize: "10px", color: C.textMuted }}>{item.name}</div>
                    <div style={{ fontSize: "12px", fontWeight: 600, color: C.textSecondary }}>
                      {typeof item.price === "number" ? `¥${item.price}/吨` : `¥${item.price}`}
                    </div>
                  </div>
                ))}
              </div>
              <div style={{ marginTop: "6px" }}>
                <SourceBadge type={roi.source_type} />
              </div>
            </div>
          </DataCard>

          {/* Additional Insight */}
          <DataCard>
            <CardHeader title="方案优势综述" accent={C.cyan} />
            <div style={{ padding: "12px 16px", display: "flex", flexDirection: "column", gap: "8px" }}>
              {[
                { icon: TrendingDown, text: `单吨成本 ¥${roi.solution_cost_per_ton}，低于传统方案 ${savingPct}%`, color: C.green },
                { icon: ShieldCheck, text: "浸出毒性检测 100% 达标，合规无风险", color: C.blue },
                { icon: TrendingUp, text: "28d 强度 44.52 MPa，可替代 P·O42.5 水泥产品", color: C.cyan },
                { icon: CheckCircle2, text: "从危废处置转为资源化产品，政策合规性更强", color: C.purple },
              ].map((item) => {
                const Icon = item.icon;
                return (
                  <div key={item.text} style={{ display: "flex", alignItems: "flex-start", gap: "10px" }}>
                    <div
                      style={{
                        width: "28px",
                        height: "28px",
                        borderRadius: "7px",
                        background: `${item.color}18`,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        flexShrink: 0,
                        color: item.color,
                      }}
                    >
                      <Icon size={13} />
                    </div>
                    <span style={{ fontSize: "12px", color: C.textSecondary, lineHeight: 1.5, paddingTop: "4px" }}>
                      {item.text}
                    </span>
                  </div>
                );
              })}
            </div>
          </DataCard>
        </div>
      </div>
    </div>
  );
}