import React, { useState } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Cell,
  ResponsiveContainer,
  PieChart,
  Pie,
} from "recharts";
import { CheckCircle2, Star, ChevronRight, Sparkles, Info } from "lucide-react";
import { demoData } from "../data/demoData";
import { C, DataCard, CardHeader, ModuleHeader, ProgressBar, SourceBadge, ScoreRing } from "../components/shared";

const BOM_COLORS = ["#06b6d4", "#6366f1", "#f59e0b", "#10b981", "#8b5cf6", "#ef4444"];

const MATERIAL_ACCENTS: Record<string, string> = {
  low_carbon_binder: "#06b6d4",
  roadbase_repair: "#10b981",
  soft_soil_stabilizer: "#3b82f6",
  soil_remediation: "#8b5cf6",
};

const ADVANTAGE_TEXT: Record<string, string[]> = {
  low_carbon_binder: [
    "锰渣掺量最高（50%），去化效率最优",
    "28d 强度 44.52 MPa，远超工程要求",
    "碳减排 1,800 tCO₂e，CCER 收益最大",
    "胶凝活性指数高，激发效果稳定",
  ],
  roadbase_repair: [
    "适用于铁路/公路路基回填",
    "锰渣掺量 35%，综合成本低",
    "28d 强度 17.8 MPa，满足路基要求",
    "与大西南铁路需求高度匹配",
  ],
  soft_soil_stabilizer: [
    "适配高含水场景原位处理",
    "无需额外干燥预处理",
    "强度数据待中试阶段验证",
    "应急处置灵活性强",
  ],
  soil_remediation: [
    "可做低品位去化备选方向",
    "锰渣掺量相对较低（20%）",
    "更多参数待试验数据支撑",
    "适合农田修复场景补充供应",
  ],
};

export default function Module3() {
  const { materials } = demoData;
  const [selectedId, setSelectedId] = useState("low_carbon_binder");
  const selectedMaterial = materials.find((m) => m.material_id === selectedId)!;
  const accent = MATERIAL_ACCENTS[selectedId] || C.cyan;

  const matchData = materials.map((m) => ({
    name: m.material_name,
    score: m.match_score,
    recommended: m.is_recommended,
    id: m.material_id,
  }));

  const bomTotal = selectedMaterial.bom.reduce((s, b) => s + b.pct, 0);

  return (
    <div>
      <ModuleHeader
        step={3}
        title="AI 大脑 · 智能分质调度与配方寻优"
        description="基于 128 维特征向量，从 4 类资源化路线中输出最优配方方案"
        accentColor={C.purple}
        statusLabel="推荐已生成"
        statusColor={C.green}
      />

      {/* Material Selection Cards */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "12px", marginBottom: "16px" }}>
        {materials.map((mat) => {
          const isActive = mat.material_id === selectedId;
          const matAccent = MATERIAL_ACCENTS[mat.material_id];
          return (
            <div
              key={mat.material_id}
              onClick={() => setSelectedId(mat.material_id)}
              style={{
                background: isActive ? `${matAccent}15` : C.bgCard,
                border: isActive ? `1px solid ${matAccent}60` : mat.is_recommended ? `1px solid ${matAccent}30` : `1px solid ${C.borderSubtle}`,
                borderRadius: "14px",
                padding: "16px",
                cursor: "pointer",
                transition: "all 0.2s ease",
                boxShadow: isActive ? `0 0 20px ${matAccent}20` : "none",
                position: "relative",
                overflow: "hidden",
              }}
            >
              {/* Top accent line */}
              <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "2px", background: isActive ? matAccent : "transparent", transition: "all 0.3s" }} />

              {/* Recommended badge */}
              {mat.is_recommended && (
                <div
                  style={{
                    position: "absolute",
                    top: "10px",
                    right: "10px",
                    display: "flex",
                    alignItems: "center",
                    gap: "3px",
                    padding: "2px 8px",
                    background: "rgba(16,185,129,0.2)",
                    border: "1px solid rgba(16,185,129,0.5)",
                    borderRadius: "20px",
                  }}
                >
                  <Star size={8} color={C.green} fill={C.green} />
                  <span style={{ fontSize: "9px", fontWeight: 700, color: C.green }}>推荐</span>
                </div>
              )}

              <ScoreRing score={mat.match_score} size={72} accent={matAccent} />

              <div style={{ marginTop: "8px" }}>
                <div style={{ fontSize: "14px", fontWeight: 700, color: isActive ? matAccent : C.textPrimary }}>
                  {mat.material_name}
                </div>
                <div style={{ fontSize: "11px", color: C.textMuted, marginTop: "4px", lineHeight: 1.4 }}>
                  {mat.reason}
                </div>
              </div>

              <div style={{ marginTop: "10px", display: "flex", alignItems: "center", gap: "4px" }}>
                <div style={{ fontSize: "11px", fontWeight: 600, color: matAccent }}>查看配方</div>
                <ChevronRight size={11} color={matAccent} />
              </div>
            </div>
          );
        })}
      </div>

      {/* Detail Section */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px" }}>

        {/* BOM Composition */}
        <DataCard glowing={selectedMaterial.is_recommended} accent={accent}>
          <CardHeader
            title={`BOM 配方 · ${selectedMaterial.material_name}`}
            subtitle={`配比组成 · ${selectedMaterial.bom.length} 种原料`}
            accent={accent}
            right={<SourceBadge type={selectedMaterial.bom[0]?.source_type || "demo_assumption"} />}
          />
          <div style={{ padding: "12px 16px" }}>
            {/* Stacked bar */}
            <div style={{ marginBottom: "12px" }}>
              <div style={{ display: "flex", borderRadius: "8px", overflow: "hidden", height: "28px" }}>
                {selectedMaterial.bom.map((b, i) => (
                  <div
                    key={b.name}
                    style={{
                      width: `${b.pct}%`,
                      background: BOM_COLORS[i % BOM_COLORS.length],
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      transition: "all 0.5s ease",
                    }}
                    title={`${b.name}: ${b.pct}%`}
                  >
                    {b.pct >= 10 && (
                      <span style={{ fontSize: "10px", fontWeight: 700, color: "rgba(0,0,0,0.7)" }}>
                        {b.pct}%
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* BOM Items */}
            <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
              {selectedMaterial.bom.map((item, i) => (
                <div
                  key={item.name}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "10px",
                    padding: "10px 12px",
                    background: `${BOM_COLORS[i % BOM_COLORS.length]}10`,
                    border: `1px solid ${BOM_COLORS[i % BOM_COLORS.length]}25`,
                    borderRadius: "8px",
                  }}
                >
                  <div
                    style={{
                      width: "10px",
                      height: "10px",
                      borderRadius: "2px",
                      background: BOM_COLORS[i % BOM_COLORS.length],
                      flexShrink: 0,
                    }}
                  />
                  <span style={{ fontSize: "13px", fontWeight: 600, color: C.textPrimary, flex: 1 }}>
                    {item.name}
                  </span>
                  <span style={{ fontSize: "13px", fontWeight: 700, color: BOM_COLORS[i % BOM_COLORS.length] }}>
                    {item.pct}%
                  </span>
                  <div style={{ textAlign: "right" }}>
                    {item.unit_price_cny_per_ton !== null && item.unit_price_cny_per_ton !== undefined ? (
                      <span style={{ fontSize: "12px", color: C.textSecondary }}>
                        ¥{item.unit_price_cny_per_ton}/吨
                      </span>
                    ) : item.unit_price_cny_per_ton === 0 ? (
                      <span style={{ fontSize: "12px", color: C.green }}>免费（废渣）</span>
                    ) : (
                      <span style={{ fontSize: "11px", color: C.textMuted }}>待补充</span>
                    )}
                  </div>
                  <SourceBadge type={item.source_type} />
                </div>
              ))}
            </div>

            {/* If recommended show process suggestion */}
            {selectedMaterial.is_recommended && (
              <div
                style={{
                  marginTop: "12px",
                  padding: "10px 12px",
                  background: "linear-gradient(135deg, rgba(6,182,212,0.1), rgba(59,130,246,0.1))",
                  border: "1px solid rgba(6,182,212,0.3)",
                  borderRadius: "8px",
                }}
              >
                <div style={{ display: "flex", alignItems: "center", gap: "6px", marginBottom: "4px" }}>
                  <Sparkles size={12} color={accent} />
                  <span style={{ fontSize: "11px", fontWeight: 700, color: accent }}>工艺建议</span>
                </div>
                <div style={{ fontSize: "11px", color: C.textSecondary, lineHeight: 1.5 }}>
                  脱氨 → 调湿至含水率 20% → 分级筛分（75μm 筛网）→ 矿渣混合激发 → 熟石灰中和 → 养护 28d
                </div>
              </div>
            )}
          </div>
        </DataCard>

        {/* Match Score + Advantage */}
        <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
          {/* Advantage Points */}
          <DataCard glowing={selectedMaterial.is_recommended} accent={accent} style={{ flex: "0 0 auto" }}>
            <CardHeader
              title="推荐依据"
              subtitle={selectedMaterial.is_recommended ? "AI 首选路线" : "备选路线"}
              accent={accent}
              right={
                selectedMaterial.is_recommended ? (
                  <div style={{ display: "flex", alignItems: "center", gap: "4px", padding: "3px 10px", background: `${C.green}20`, border: `1px solid ${C.green}40`, borderRadius: "20px" }}>
                    <CheckCircle2 size={11} color={C.green} />
                    <span style={{ fontSize: "11px", fontWeight: 600, color: C.green }}>AI 首推</span>
                  </div>
                ) : null
              }
            />
            <div style={{ padding: "12px 16px" }}>
              <div style={{ fontSize: "13px", color: C.textSecondary, marginBottom: "12px", lineHeight: 1.5 }}>
                {selectedMaterial.reason}
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
                {(ADVANTAGE_TEXT[selectedMaterial.material_id] || []).map((adv, i) => (
                  <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: "8px" }}>
                    <div
                      style={{
                        width: "16px",
                        height: "16px",
                        borderRadius: "50%",
                        background: `${accent}25`,
                        border: `1px solid ${accent}50`,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        flexShrink: 0,
                        marginTop: "1px",
                        fontSize: "9px",
                        fontWeight: 700,
                        color: accent,
                      }}
                    >
                      {i + 1}
                    </div>
                    <span style={{ fontSize: "12px", color: C.textSecondary, lineHeight: 1.5 }}>{adv}</span>
                  </div>
                ))}
              </div>
            </div>
          </DataCard>

          {/* Match Score Comparison Bar Chart */}
          <DataCard style={{ flex: 1 }}>
            <CardHeader title="四类路线匹配度对比" subtitle="Match Score Comparison" accent={C.purple} />
            <div style={{ padding: "8px 8px 12px" }}>
              <ResponsiveContainer width="100%" height={185}>
                <BarChart data={matchData} layout="vertical" margin={{ top: 0, right: 40, left: 10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(6,182,212,0.08)" horizontal={false} />
                  <XAxis
                    type="number"
                    domain={[0, 100]}
                    tick={{ fill: C.textMuted, fontSize: 10 }}
                    axisLine={{ stroke: C.borderSubtle }}
                    tickLine={false}
                  />
                  <YAxis
                    dataKey="name"
                    type="category"
                    tick={{ fill: C.textSecondary, fontSize: 11 }}
                    axisLine={false}
                    tickLine={false}
                    width={90}
                  />
                  <Tooltip
                    contentStyle={{
                      background: C.bgCard,
                      border: `1px solid ${C.borderSubtle}`,
                      borderRadius: "8px",
                      fontSize: "12px",
                      color: C.textPrimary,
                    }}
                    formatter={(v: number) => [`${v}分`, "匹配度"]}
                  />
                  <Bar dataKey="score" radius={[0, 4, 4, 0]} label={{ position: "right", fill: C.textSecondary, fontSize: 11, formatter: (v: number) => `${v}` }}>
                    {matchData.map((entry) => (
                      <Cell
                        key={entry.id}
                        fill={entry.id === selectedId ? MATERIAL_ACCENTS[entry.id] : `${MATERIAL_ACCENTS[entry.id]}60`}
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </DataCard>
        </div>
      </div>
    </div>
  );
}
