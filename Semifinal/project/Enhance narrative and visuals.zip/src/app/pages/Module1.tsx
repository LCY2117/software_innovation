import React, { useEffect, useState } from "react";
import { Battery, Thermometer, Droplets, Navigation2, Wifi, Activity, MapPin, Clock, AlertTriangle } from "lucide-react";
import { demoData } from "../data/demoData";
import { C, DataCard, CardHeader, ModuleHeader, ProgressBar, StatCard } from "../components/shared";

const SAMPLE_POINTS = [
  { x: 120, y: 80,  id: "SP-01", status: "sampled", ph: 6.9, mn: 178 },
  { x: 200, y: 55,  id: "SP-02", status: "sampled", ph: 6.7, mn: 185 },
  { x: 280, y: 90,  id: "SP-03", status: "sampled", ph: 6.8, mn: 182 },
  { x: 170, y: 130, id: "SP-04", status: "sampled", ph: 7.0, mn: 176 },
  { x: 250, y: 155, id: "SP-05", status: "sampling", ph: null, mn: null },
  { x: 330, y: 120, id: "SP-06", status: "pending", ph: null, mn: null },
  { x: 310, y: 60,  id: "SP-07", status: "pending", ph: null, mn: null },
];

const TELEMETRY_STREAM = [
  "pH=6.84 · Mn=179mg/L · NH₃=312mg/L",
  "Temp=18.3°C · Humidity=71% · Tilt=3.2°",
  "GPS: 27.7191°N, 109.1916°E · Alt=312m",
  "Speed=0.8km/h · Battery=68% · Signal=5/5",
  "粒径采样中… d50=128μm ±8μm",
  "渗滤液检测: 超标 ×2 | 浸出液: 正常",
];

export default function Module1() {
  const { sampling, batch } = demoData;
  const [streamIdx, setStreamIdx] = useState(0);
  const [scanAngle, setScanAngle] = useState(0);
  const [elapsed, setElapsed] = useState(0);

  useEffect(() => {
    const t1 = setInterval(() => setStreamIdx((i) => (i + 1) % TELEMETRY_STREAM.length), 2200);
    const t2 = setInterval(() => setScanAngle((a) => (a + 2) % 360), 50);
    const t3 = setInterval(() => setElapsed((e) => e + 1), 1000);
    return () => { clearInterval(t1); clearInterval(t2); clearInterval(t3); };
  }, []);

  const formatTime = (s: number) => `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
  const { lt_75um_pct, mid_pct, gt_500um_pct } = sampling.particle_size_distribution;

  return (
    <div>
      <ModuleHeader
        step={1}
        title="边缘感知 · 全地形无人勘探系统"
        description="自主导航小车原位采样，替代高危人工作业 · 实时 Telemetry 上传"
        accentColor={C.cyan}
        statusLabel="勘探中"
        statusColor={C.cyan}
      />

      {/* Quick Stats Row */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "12px", marginBottom: "16px" }}>
        <StatCard label="电量" value="68" unit="%" accent={C.green} icon={<Battery size={14} />} sub="预计剩余 2.4h" />
        <StatCard label="行驶速度" value="0.8" unit="km/h" accent={C.cyan} icon={<Navigation2 size={14} />} sub="坡度 3.2°" />
        <StatCard label="信号强度" value="5/5" accent={C.blue} icon={<Wifi size={14} />} sub="延迟 18ms" />
        <StatCard label="已采样点" value="4" unit="/7" accent={C.amber} icon={<MapPin size={14} />} sub={`本批次 ${batch.total_quantity_tons.toLocaleString()} 吨`} />
      </div>

      {/* Main Grid */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px", marginBottom: "16px" }}>

        {/* Camera View */}
        <DataCard>
          <CardHeader title="第一视角 · 实时画面" subtitle="Camera Feed · Edge AI Overlay" accent={C.cyan} right={
            <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
              <div style={{ width: "6px", height: "6px", borderRadius: "50%", background: "#ef4444" }} className="animate-pulse" />
              <span style={{ fontSize: "11px", fontWeight: 600, color: "#ef4444" }}>REC</span>
            </div>
          } />
          <div style={{ position: "relative", background: "#020810", height: "240px", overflow: "hidden" }}>
            {/* Grid overlay */}
            <svg style={{ position: "absolute", inset: 0, width: "100%", height: "100%", opacity: 0.12 }}>
              <defs>
                <pattern id="grid1" width="40" height="40" patternUnits="userSpaceOnUse">
                  <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#06b6d4" strokeWidth="0.5" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid1)" />
            </svg>

            {/* Scan line */}
            <div
              className="scan-anim"
              style={{
                position: "absolute",
                left: 0,
                right: 0,
                height: "1px",
                background: "linear-gradient(90deg, transparent, rgba(6,182,212,0.8), transparent)",
                boxShadow: "0 0 8px rgba(6,182,212,0.5)",
              }}
            />

            {/* Corner markers */}
            {(["tl", "tr", "bl", "br"] as const).map((corner) => {
              const top    = corner === "tl" || corner === "tr" ? 8    : undefined;
              const bottom = corner === "bl" || corner === "br" ? 8    : undefined;
              const left   = corner === "tl" || corner === "bl" ? 8    : undefined;
              const right  = corner === "tr" || corner === "br" ? 8    : undefined;
              const d =
                corner === "tl" ? "M0,12 L0,0 L12,0"  :
                corner === "tr" ? "M8,0 L20,0 L20,12"  :
                corner === "bl" ? "M0,8 L0,20 L12,20"  :
                                  "M8,20 L20,20 L20,8";
              return (
                <div key={corner} style={{ position: "absolute", top, right, bottom, left, width: 20, height: 20 }}>
                  <svg width="20" height="20"><path d={d} stroke="#06b6d4" strokeWidth="1.5" fill="none" /></svg>
                </div>
              );
            })}

            {/* Center crosshair */}
            <svg style={{ position: "absolute", inset: 0, width: "100%", height: "100%", opacity: 0.4 }}>
              <line x1="50%" y1="40%" x2="50%" y2="60%" stroke="#06b6d4" strokeWidth="1" />
              <line x1="40%" y1="50%" x2="60%" y2="50%" stroke="#06b6d4" strokeWidth="1" />
              <circle cx="50%" cy="50%" r="20" stroke="#06b6d4" strokeWidth="0.5" fill="none" />
            </svg>

            {/* Status overlays */}
            <div style={{ position: "absolute", top: "10px", left: "10px" }}>
              <div style={{ fontSize: "11px", fontWeight: 700, color: "#06b6d4", letterSpacing: "0.08em" }}>LIVE · {formatTime(elapsed)}</div>
              <div style={{ fontSize: "10px", color: "rgba(148,163,184,0.8)", marginTop: "2px" }}>SP-05 · 采样中</div>
            </div>

            <div style={{ position: "absolute", bottom: "10px", left: "10px" }}>
              <div style={{ fontSize: "10px", fontWeight: 600, color: "rgba(6,182,212,0.9)", fontFamily: "monospace" }}>
                {TELEMETRY_STREAM[streamIdx]}
              </div>
            </div>

            <div style={{ position: "absolute", top: "10px", right: "10px", textAlign: "right" }}>
              <div style={{ fontSize: "10px", color: "rgba(148,163,184,0.7)" }}>{batch.lat}°N</div>
              <div style={{ fontSize: "10px", color: "rgba(148,163,184,0.7)" }}>{batch.lng}°E</div>
              <div style={{ fontSize: "10px", color: "rgba(148,163,184,0.7)", marginTop: "2px" }}>Alt 312m</div>
            </div>

            {/* AI detection box (simulated) */}
            <div style={{ position: "absolute", left: "30%", top: "25%", width: "80px", height: "60px", border: "1px solid rgba(245,158,11,0.7)", boxShadow: "0 0 8px rgba(245,158,11,0.3)" }}>
              <span style={{ position: "absolute", top: "-16px", left: 0, fontSize: "9px", color: "#f59e0b", fontWeight: 600 }}>渣堆边界 AI-Det</span>
            </div>
          </div>
        </DataCard>

        {/* Sampling Parameters */}
        <DataCard>
          <CardHeader title="原位采样参数" subtitle="来源: demo_assumption" accent={C.cyan} />
          <div style={{ padding: "12px 16px", display: "flex", flexDirection: "column", gap: "10px" }}>
            {[
              { label: "可溶性锰 Mn²⁺", value: `${sampling.soluble_manganese_mg_l} mg/L`, threshold: "≤2 mg/L", risk: "高", color: C.red, pct: 91 },
              { label: "氨氮 NH₃-N", value: `${sampling.ammonia_nitrogen_mg_l} mg/L`, threshold: "≤25 mg/L", risk: "高", color: C.red, pct: 88 },
              { label: "含水率", value: `${sampling.water_content_pct}%`, threshold: "≤30%", risk: "中", color: C.amber, pct: 58 },
              { label: "pH 值", value: `${sampling.ph}`, threshold: "6~9", risk: "正常", color: C.green, pct: 32 },
            ].map((item) => (
              <div key={item.label}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "5px" }}>
                  <div>
                    <span style={{ fontSize: "12px", fontWeight: 500, color: C.textSecondary }}>{item.label}</span>
                    <span style={{ fontSize: "11px", color: C.textMuted, marginLeft: "8px" }}>标准限值 {item.threshold}</span>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                    <span style={{ fontSize: "13px", fontWeight: 700, color: item.color }}>{item.value}</span>
                    <span
                      style={{
                        fontSize: "10px",
                        fontWeight: 600,
                        color: item.color,
                        background: `${item.color}18`,
                        border: `1px solid ${item.color}40`,
                        borderRadius: "4px",
                        padding: "1px 6px",
                      }}
                    >
                      {item.risk}
                    </span>
                  </div>
                </div>
                <ProgressBar value={item.pct} accent={item.color} height={4} />
              </div>
            ))}

            {/* Particle Size */}
            <div>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "6px" }}>
                <span style={{ fontSize: "12px", fontWeight: 500, color: C.textSecondary }}>粒径分布</span>
                <span style={{ fontSize: "11px", color: C.textMuted }}>Particle Size Distribution</span>
              </div>
              <div style={{ display: "flex", borderRadius: "6px", overflow: "hidden", height: "20px" }}>
                <div style={{ width: `${lt_75um_pct}%`, background: "#06b6d4", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <span style={{ fontSize: "10px", fontWeight: 600, color: "#040c1c" }}>&lt;75μm {lt_75um_pct}%</span>
                </div>
                <div style={{ width: `${mid_pct}%`, background: "#3b82f6", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <span style={{ fontSize: "10px", fontWeight: 600, color: "white" }}>{mid_pct}%</span>
                </div>
                <div style={{ width: `${gt_500um_pct}%`, background: "#6366f1", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <span style={{ fontSize: "10px", fontWeight: 600, color: "white" }}>{gt_500um_pct}%</span>
                </div>
              </div>
              <div style={{ display: "flex", gap: "12px", marginTop: "5px" }}>
                {[
                  { color: "#06b6d4", label: `<75μm (${lt_75um_pct}%)` },
                  { color: "#3b82f6", label: `75–500μm (${mid_pct}%)` },
                  { color: "#6366f1", label: `>500μm (${gt_500um_pct}%)` },
                ].map((l) => (
                  <div key={l.label} style={{ display: "flex", alignItems: "center", gap: "4px" }}>
                    <div style={{ width: "8px", height: "8px", borderRadius: "2px", background: l.color }} />
                    <span style={{ fontSize: "10px", color: C.textMuted }}>{l.label}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </DataCard>
      </div>

      {/* Scan Map */}
      <DataCard>
        <CardHeader
          title="堆场扫描轨迹 · 采样点位分布"
          subtitle={`${batch.site_name} · 数字孪生预览`}
          accent={C.cyan}
          right={
            <div style={{ display: "flex", gap: "16px" }}>
              {[
                { color: C.green, label: "已采样 (4)" },
                { color: C.amber, label: "采样中 (1)" },
                { color: C.textMuted, label: "待采样 (2)" },
              ].map((l) => (
                <div key={l.label} style={{ display: "flex", alignItems: "center", gap: "5px" }}>
                  <div style={{ width: "8px", height: "8px", borderRadius: "50%", background: l.color }} />
                  <span style={{ fontSize: "11px", color: C.textMuted }}>{l.label}</span>
                </div>
              ))}
            </div>
          }
        />
        <div style={{ padding: "12px 16px", position: "relative", height: "200px" }}>
          <svg width="100%" height="100%" viewBox="0 0 500 190" style={{ overflow: "visible" }}>
            {/* Background grid */}
            <defs>
              <pattern id="scanGrid" width="25" height="25" patternUnits="userSpaceOnUse">
                <path d="M 25 0 L 0 0 0 25" fill="none" stroke="rgba(6,182,212,0.08)" strokeWidth="0.5" />
              </pattern>
              <radialGradient id="heapGrad" cx="50%" cy="50%">
                <stop offset="0%" stopColor="rgba(6,182,212,0.15)" />
                <stop offset="100%" stopColor="rgba(6,182,212,0.02)" />
              </radialGradient>
            </defs>
            <rect width="500" height="190" fill="url(#scanGrid)" rx="8" />

            {/* Heap area */}
            <ellipse cx="225" cy="105" rx="180" ry="75" fill="url(#heapGrad)" stroke="rgba(6,182,212,0.2)" strokeWidth="1" strokeDasharray="4 3" />

            {/* Scan path (zigzag pattern) */}
            <polyline
              points="90,70 190,50 280,70 360,50 420,75 420,110 330,130 230,105 130,130 90,110 90,70"
              fill="none"
              stroke="rgba(6,182,212,0.25)"
              strokeWidth="1.5"
              strokeDasharray="6 4"
            />

            {/* Sample points */}
            {SAMPLE_POINTS.map((pt) => {
              const color = pt.status === "sampled" ? C.green : pt.status === "sampling" ? C.amber : C.textMuted;
              return (
                <g key={pt.id}>
                  <circle cx={pt.x} cy={pt.y} r="10" fill={`${color}15`} stroke={`${color}40`} strokeWidth="1" />
                  <circle cx={pt.x} cy={pt.y} r="4" fill={color} />
                  <text x={pt.x + 8} y={pt.y - 8} fill={color} style={{ fontSize: "9px", fontWeight: 600 }}>{pt.id}</text>
                  {pt.ph && (
                    <text x={pt.x + 8} y={pt.y + 4} fill="rgba(148,163,184,0.7)" style={{ fontSize: "8px" }}>
                      pH={pt.ph}
                    </text>
                  )}
                </g>
              );
            })}

            {/* Robot car position (at SP-05) */}
            <g>
              <circle cx={250} cy={155} r="14" fill="rgba(245,158,11,0.15)" stroke="rgba(245,158,11,0.6)" strokeWidth="1.5" className="animate-pulse" />
              <text x={250} y={155} textAnchor="middle" dominantBaseline="middle" style={{ fontSize: "12px" }}>🤖</text>
              {/* Radar sweep */}
              <line
                x1={250}
                y1={155}
                x2={250 + 40 * Math.cos((scanAngle * Math.PI) / 180)}
                y2={155 + 40 * Math.sin((scanAngle * Math.PI) / 180)}
                stroke="rgba(6,182,212,0.6)"
                strokeWidth="1.5"
                strokeLinecap="round"
              />
              <circle cx={250} cy={155} r="40" fill="none" stroke="rgba(6,182,212,0.1)" strokeWidth="1" />
            </g>

            {/* Site label */}
            <text x="225" y="183" textAnchor="middle" fill="rgba(148,163,184,0.5)" style={{ fontSize: "10px" }}>
              {batch.site_name} · Digital Twin Preview
            </text>
          </svg>
        </div>
      </DataCard>
    </div>
  );
}