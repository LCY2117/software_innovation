import React, { useState } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";
import { Truck, Leaf, Award, ArrowRight, CheckCircle2, Zap, FileText } from "lucide-react";
import { demoData } from "../data/demoData";
import { C, DataCard, CardHeader, ModuleHeader, ProgressBar, SourceBadge, Badge } from "../components/shared";

const TYPE_COLORS: Record<string, string> = {
  铁路工程: C.cyan,
  预制构件: C.blue,
};

export default function Module5() {
  const { buyers, carbon, batch } = demoData;
  const [activeContract, setActiveContract] = useState<string | null>(null);
  const [sentContracts, setSentContracts] = useState<string[]>([]);

  const carbonKey = "low_carbon_binder";
  const carbonData = carbon[carbonKey as keyof typeof carbon];

  const totalBuyerTons = buyers.reduce((s, b) => s + b.planned_quantity_tons, 0);
  const totalTransport = buyers.reduce((s, b) => s + b.estimated_transport_cost_cny, 0);
  const totalCarbon = Object.values(carbon).reduce((s, c) => s + c.reduction_tco2e, 0);
  const totalCarbonRevenue = Object.values(carbon).reduce((s, c) => s + c.forward_revenue_cny, 0);

  const carbonChartData = [
    { name: "低碳胶凝", tco2e: carbon.low_carbon_binder.reduction_tco2e, revenue: carbon.low_carbon_binder.forward_revenue_cny / 1000 },
    { name: "路基修复", tco2e: carbon.roadbase_repair.reduction_tco2e, revenue: carbon.roadbase_repair.forward_revenue_cny / 1000 },
    { name: "软土固化", tco2e: carbon.soft_soil_stabilizer.reduction_tco2e, revenue: carbon.soft_soil_stabilizer.forward_revenue_cny / 1000 },
    { name: "土壤改良", tco2e: carbon.soil_remediation.reduction_tco2e, revenue: carbon.soil_remediation.forward_revenue_cny / 1000 },
  ];

  const handleContract = (id: string) => {
    setSentContracts((prev) => [...prev, id]);
    setActiveContract(id);
    setTimeout(() => setActiveContract(null), 2000);
  };

  return (
    <div>
      <ModuleHeader
        step={5}
        title="商业闭环 · 供需撮合与碳资产管理"
        description="需求方匹配 → 一键派单 → CCER 碳减排核算 → 产业价值全闭环"
        accentColor={C.amber}
        statusLabel="2 个买家已匹配"
        statusColor={C.green}
      />

      {/* Top Summary */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "12px", marginBottom: "16px" }}>
        {[
          { label: "已匹配需求量", value: `${totalBuyerTons.toLocaleString()}`, unit: "吨", accent: C.cyan, sub: `共 ${buyers.length} 家买方` },
          { label: "锰渣去化率", value: `${Math.round((totalBuyerTons / batch.total_quantity_tons) * 100)}%`, accent: C.green, sub: `${totalBuyerTons}/${batch.total_quantity_tons} 吨` },
          { label: "碳减排总量", value: `${carbonData.reduction_tco2e.toLocaleString()}`, unit: "tCO₂e", accent: C.green, sub: "低碳胶凝材料路线" },
          { label: "CCER 预期收益", value: `¥${(carbonData.forward_revenue_cny / 10000).toFixed(2)}万`, accent: C.amber, sub: `碳价 ¥${carbonData.carbon_price_cny_per_tco2e}/tCO₂e` },
        ].map((item) => (
          <div
            key={item.label}
            style={{
              background: C.bgCard,
              border: `1px solid ${C.borderSubtle}`,
              borderRadius: "12px",
              padding: "16px",
              position: "relative",
              overflow: "hidden",
            }}
          >
            <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "2px", background: `linear-gradient(90deg, transparent, ${item.accent}, transparent)` }} />
            <div style={{ fontSize: "10px", fontWeight: 600, color: C.textMuted, textTransform: "uppercase", letterSpacing: "0.08em" }}>{item.label}</div>
            <div style={{ display: "flex", alignItems: "baseline", gap: "4px", marginTop: "4px" }}>
              <span style={{ fontSize: "24px", fontWeight: 800, color: item.accent }}>{item.value}</span>
              {item.unit && <span style={{ fontSize: "12px", color: C.textMuted }}>{item.unit}</span>}
            </div>
            <div style={{ fontSize: "11px", color: C.textMuted, marginTop: "2px" }}>{item.sub}</div>
          </div>
        ))}
      </div>

      {/* Main 3-col Grid */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1.4fr 1fr", gap: "16px" }}>

        {/* Buyer List */}
        <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
          <DataCard style={{ flex: 1 }}>
            <CardHeader title="需求方匹配" subtitle="Buyer Matching · AI Ranked" accent={C.amber} right={
              <span style={{ fontSize: "11px", fontWeight: 600, color: C.green }}>
                {buyers.length} 家已匹配
              </span>
            } />
            <div style={{ padding: "12px 16px", display: "flex", flexDirection: "column", gap: "12px" }}>
              {buyers.map((buyer, i) => {
                const color = TYPE_COLORS[buyer.buyer_type] || C.cyan;
                const isSent = sentContracts.includes(buyer.buyer_id);
                return (
                  <div
                    key={buyer.buyer_id}
                    style={{
                      padding: "14px",
                      background: i === 0 ? `${C.cyan}0c` : `${C.blue}0c`,
                      border: `1px solid ${color}30`,
                      borderRadius: "12px",
                      position: "relative",
                      overflow: "hidden",
                    }}
                  >
                    <div style={{ position: "absolute", top: 0, left: 0, width: "3px", height: "100%", background: color, borderRadius: "3px 0 0 3px" }} />
                    <div style={{ paddingLeft: "8px" }}>
                      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                        <div>
                          <div style={{ fontSize: "14px", fontWeight: 700, color: C.textPrimary }}>{buyer.buyer_name}</div>
                          <div style={{ display: "flex", alignItems: "center", gap: "6px", marginTop: "3px" }}>
                            <span style={{ fontSize: "10px", padding: "1px 7px", background: `${color}20`, border: `1px solid ${color}40`, borderRadius: "4px", color: color, fontWeight: 600 }}>
                              {buyer.buyer_type}
                            </span>
                            <span style={{ fontSize: "11px", color: C.textMuted }}>距离 {buyer.distance_km} km</span>
                          </div>
                        </div>
                        <div style={{ textAlign: "center" }}>
                          <div style={{ fontSize: "22px", fontWeight: 800, color: color }}>{buyer.match_score}</div>
                          <div style={{ fontSize: "9px", color: C.textMuted }}>匹配度</div>
                        </div>
                      </div>

                      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "6px", marginTop: "10px" }}>
                        {[
                          { label: "需求量", value: `${buyer.planned_quantity_tons.toLocaleString()} 吨` },
                          { label: "运输费", value: `¥${buyer.estimated_transport_cost_cny.toLocaleString()}` },
                        ].map((m) => (
                          <div key={m.label} style={{ padding: "5px 8px", background: `${color}08`, borderRadius: "6px" }}>
                            <div style={{ fontSize: "10px", color: C.textMuted }}>{m.label}</div>
                            <div style={{ fontSize: "12px", fontWeight: 600, color: C.textSecondary }}>{m.value}</div>
                          </div>
                        ))}
                      </div>

                      <button
                        onClick={() => handleContract(buyer.buyer_id)}
                        style={{
                          marginTop: "10px",
                          width: "100%",
                          padding: "8px",
                          background: isSent ? `${C.green}20` : `${color}20`,
                          border: `1px solid ${isSent ? C.green : color}60`,
                          borderRadius: "8px",
                          color: isSent ? C.green : color,
                          fontSize: "12px",
                          fontWeight: 600,
                          cursor: "pointer",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          gap: "6px",
                          transition: "all 0.3s",
                        }}
                      >
                        {isSent ? (
                          <><CheckCircle2 size={13} /> 合同已发送</>
                        ) : (
                          <><FileText size={13} /> 一键生成合同</>
                        )}
                      </button>
                    </div>

                    <SourceBadge type={buyer.source_type} />
                  </div>
                );
              })}
            </div>
          </DataCard>
        </div>

        {/* Map Visualization */}
        <DataCard>
          <CardHeader title="供需地理分布 · 运输半径" subtitle={`以${batch.site_name}为中心`} accent={C.cyan} />
          <div style={{ padding: "12px 16px", position: "relative" }}>
            <svg viewBox="0 0 400 340" style={{ width: "100%", height: "340px" }}>
              <defs>
                <radialGradient id="mapBg" cx="50%" cy="50%">
                  <stop offset="0%" stopColor="rgba(6,182,212,0.08)" />
                  <stop offset="100%" stopColor="rgba(4,12,28,0)" />
                </radialGradient>
                <radialGradient id="siteGlow">
                  <stop offset="0%" stopColor="rgba(6,182,212,0.4)" />
                  <stop offset="100%" stopColor="rgba(6,182,212,0)" />
                </radialGradient>
                <pattern id="mapGrid" width="20" height="20" patternUnits="userSpaceOnUse">
                  <path d="M 20 0 L 0 0 0 20" fill="none" stroke="rgba(6,182,212,0.06)" strokeWidth="0.5" />
                </pattern>
              </defs>

              <rect width="400" height="340" fill="url(#mapGrid)" rx="8" />
              <rect width="400" height="340" fill="url(#mapBg)" rx="8" />

              {/* Distance rings */}
              {[40, 80, 120, 160].map((r, i) => (
                <circle key={r} cx="200" cy="170" r={r} fill="none" stroke="rgba(6,182,212,0.1)" strokeWidth="0.8" strokeDasharray="4 3" />
              ))}
              {/* Ring labels */}
              <text x="240" y="132" fill="rgba(148,163,184,0.4)" style={{ fontSize: "9px" }}>15km</text>
              <text x="280" y="94" fill="rgba(148,163,184,0.4)" style={{ fontSize: "9px" }}>28km</text>

              {/* Connection lines */}
              {/* Buyer 1 at ~15km NE */}
              <line x1="200" y1="170" x2="268" y2="112" stroke="rgba(6,182,212,0.35)" strokeWidth="1.5" strokeDasharray="5 3" />
              {/* Buyer 2 at ~28km SW */}
              <line x1="200" y1="170" x2="115" y2="225" stroke="rgba(59,130,246,0.35)" strokeWidth="1.5" strokeDasharray="5 3" />

              {/* Site node */}
              <circle cx="200" cy="170" r="32" fill="url(#siteGlow)" />
              <circle cx="200" cy="170" r="14" fill="rgba(6,182,212,0.2)" stroke="#06b6d4" strokeWidth="1.5" />
              <circle cx="200" cy="170" r="6" fill="#06b6d4" className="animate-pulse" />

              <text x="200" y="150" textAnchor="middle" fill="#06b6d4" style={{ fontSize: "11px", fontWeight: 700 }}>
                {batch.city}锰渣堆场
              </text>
              <text x="200" y="162" textAnchor="middle" fill="rgba(148,163,184,0.6)" style={{ fontSize: "9px" }}>
                {batch.lat}°N {batch.lng}°E
              </text>

              {/* Buyer 1 Node (大西南铁路) */}
              <circle cx="268" cy="112" r="12" fill="rgba(6,182,212,0.2)" stroke="#06b6d4" strokeWidth="1.5" className="node-float" />
              <circle cx="268" cy="112" r="5" fill="#06b6d4" />
              <text x="268" y="96" textAnchor="middle" fill="#06b6d4" style={{ fontSize: "10px", fontWeight: 700 }}>
                大西南铁路施工段
              </text>
              <text x="268" y="107" textAnchor="middle" fill="rgba(148,163,184,0.6)" style={{ fontSize: "9px" }}>
                15km · 匹配度 98
              </text>
              <rect x="248" y="125" width="40" height="14" rx="4" fill="rgba(6,182,212,0.15)" stroke="rgba(6,182,212,0.4)" strokeWidth="0.8" />
              <text x="268" y="134" textAnchor="middle" fill="#06b6d4" style={{ fontSize: "9px", fontWeight: 600 }}>3,000 吨</text>

              {/* Buyer 2 Node (预制构件厂) */}
              <circle cx="115" cy="225" r="12" fill="rgba(59,130,246,0.2)" stroke="#3b82f6" strokeWidth="1.5" className="node-float" style={{ animationDelay: "1s" }} />
              <circle cx="115" cy="225" r="5" fill="#3b82f6" />
              <text x="115" y="210" textAnchor="middle" fill="#3b82f6" style={{ fontSize: "10px", fontWeight: 700 }}>
                铜仁预制构件厂
              </text>
              <text x="115" y="220" textAnchor="middle" fill="rgba(148,163,184,0.6)" style={{ fontSize: "9px" }}>
                28km · 匹配度 91
              </text>
              <rect x="95" y="238" width="40" height="14" rx="4" fill="rgba(59,130,246,0.15)" stroke="rgba(59,130,246,0.4)" strokeWidth="0.8" />
              <text x="115" y="247" textAnchor="middle" fill="#3b82f6" style={{ fontSize: "9px", fontWeight: 600 }}>2,500 吨</text>

              {/* Legend */}
              <g transform="translate(10, 300)">
                <circle cx="8" cy="8" r="5" fill="#06b6d4" />
                <text x="16" y="12" fill="rgba(148,163,184,0.7)" style={{ fontSize: "9px" }}>锰渣堆场</text>
                <circle cx="80" cy="8" r="5" fill="#10b981" />
                <text x="88" y="12" fill="rgba(148,163,184,0.7)" style={{ fontSize: "9px" }}>需求方</text>
              </g>
            </svg>
          </div>

          {/* Transport Summary */}
          <div style={{ padding: "0 16px 14px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px" }}>
            {buyers.map((b, i) => (
              <div key={b.buyer_id} style={{ padding: "8px 10px", background: `${i === 0 ? C.cyan : C.blue}0d`, border: `1px solid ${i === 0 ? C.cyan : C.blue}25`, borderRadius: "8px" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "4px", marginBottom: "4px" }}>
                  <Truck size={10} color={i === 0 ? C.cyan : C.blue} />
                  <span style={{ fontSize: "10px", fontWeight: 600, color: i === 0 ? C.cyan : C.blue }}>{b.buyer_name.slice(0, 6)}…</span>
                </div>
                <div style={{ fontSize: "11px", color: C.textSecondary }}>{b.distance_km}km · ¥{b.estimated_transport_cost_cny.toLocaleString()}</div>
              </div>
            ))}
          </div>
        </DataCard>

        {/* Carbon Asset Panel */}
        <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
          {/* CCER Header */}
          <DataCard glowing accent={C.green}>
            <div
              style={{
                padding: "16px",
                background: "linear-gradient(135deg, rgba(16,185,129,0.12), rgba(6,182,212,0.08))",
                borderBottom: `1px solid ${C.borderSubtle}`,
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "8px" }}>
                <Leaf size={18} color={C.green} />
                <span style={{ fontSize: "13px", fontWeight: 700, color: C.textPrimary }}>碳资产管理</span>
                <span style={{ fontSize: "10px", padding: "1px 7px", background: "rgba(16,185,129,0.2)", border: "1px solid rgba(16,185,129,0.4)", borderRadius: "4px", color: C.green, fontWeight: 600 }}>
                  CCER
                </span>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px" }}>
                <div style={{ padding: "10px", background: "rgba(16,185,129,0.1)", borderRadius: "8px", border: "1px solid rgba(16,185,129,0.2)" }}>
                  <div style={{ fontSize: "10px", color: C.textMuted }}>推荐路线减排量</div>
                  <div style={{ fontSize: "20px", fontWeight: 800, color: C.green }}>{carbonData.reduction_tco2e.toLocaleString()}</div>
                  <div style={{ fontSize: "10px", color: C.green }}>tCO₂e</div>
                </div>
                <div style={{ padding: "10px", background: "rgba(245,158,11,0.1)", borderRadius: "8px", border: "1px solid rgba(245,158,11,0.2)" }}>
                  <div style={{ fontSize: "10px", color: C.textMuted }}>CCER 预期收益</div>
                  <div style={{ fontSize: "20px", fontWeight: 800, color: C.amber }}>¥{(carbonData.forward_revenue_cny / 10000).toFixed(1)}万</div>
                  <div style={{ fontSize: "10px", color: C.amber }}>@¥{carbonData.carbon_price_cny_per_tco2e}/t</div>
                </div>
              </div>
              <SourceBadge type={carbonData.source_type} />
            </div>

            {/* Carbon by route chart */}
            <div style={{ padding: "12px 16px" }}>
              <div style={{ fontSize: "11px", fontWeight: 600, color: C.textMuted, marginBottom: "8px", textTransform: "uppercase", letterSpacing: "0.06em" }}>
                各路线碳减排对比 (tCO₂e)
              </div>
              <ResponsiveContainer width="100%" height={150}>
                <BarChart data={carbonChartData} margin={{ top: 0, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="2 2" stroke="rgba(6,182,212,0.08)" vertical={false} />
                  <XAxis dataKey="name" tick={{ fill: C.textMuted, fontSize: 9 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: C.textMuted, fontSize: 9 }} axisLine={false} tickLine={false} />
                  <Tooltip
                    contentStyle={{ background: C.bgCard, border: `1px solid ${C.borderSubtle}`, borderRadius: "8px", fontSize: "11px", color: C.textPrimary }}
                    formatter={(v: number) => [`${v} tCO₂e`, "减排量"]}
                  />
                  <Bar dataKey="tco2e" radius={[4, 4, 0, 0]}>
                    {carbonChartData.map((_, i) => (
                      <Cell key={i} fill={i === 0 ? C.green : `${C.green}${60 - i * 10}`} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </DataCard>

          {/* Value Loop Summary */}
          <DataCard>
            <CardHeader title="商业价值闭环" accent={C.amber} />
            <div style={{ padding: "12px 16px", display: "flex", flexDirection: "column", gap: "6px" }}>
              {[
                { label: "成本节省", value: `¥${(demoData.roi.gross_saving / 10000).toFixed(0)} 万`, color: C.green, icon: "💰" },
                { label: "运输总成本", value: `¥${(totalTransport / 10000).toFixed(1)} 万`, color: C.cyan, icon: "🚛" },
                { label: "碳资产收益", value: `¥${(carbonData.forward_revenue_cny / 10000).toFixed(2)} 万`, color: C.green, icon: "🌿" },
                { label: "锰渣去化量", value: `${totalBuyerTons.toLocaleString()} 吨`, color: C.amber, icon: "♻️" },
              ].map((item) => (
                <div
                  key={item.label}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    padding: "8px 10px",
                    background: `${item.color}0a`,
                    borderRadius: "8px",
                    border: `1px solid ${item.color}20`,
                  }}
                >
                  <div style={{ display: "flex", alignItems: "center", gap: "7px" }}>
                    <span>{item.icon}</span>
                    <span style={{ fontSize: "12px", color: C.textSecondary }}>{item.label}</span>
                  </div>
                  <span style={{ fontSize: "13px", fontWeight: 700, color: item.color }}>{item.value}</span>
                </div>
              ))}

              <div
                style={{
                  marginTop: "6px",
                  padding: "12px",
                  background: "linear-gradient(135deg, rgba(245,158,11,0.1), rgba(16,185,129,0.08))",
                  border: "1px solid rgba(245,158,11,0.3)",
                  borderRadius: "10px",
                  textAlign: "center",
                }}
              >
                <div style={{ fontSize: "10px", color: C.textMuted, marginBottom: "3px" }}>
                  危废→产品 · 市场化闭环
                </div>
                <div style={{ fontSize: "12px", fontWeight: 600, color: C.amber, lineHeight: 1.5 }}>
                  一键撮合 · 合同生成 · 碳资产核发<br />
                  <span style={{ color: C.textMuted, fontWeight: 400 }}>从处置负担到产业价值链</span>
                </div>
              </div>
            </div>
          </DataCard>
        </div>
      </div>
    </div>
  );
}
