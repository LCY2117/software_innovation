import React, { useEffect, useState } from "react";
import {
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  Radar,
  ResponsiveContainer,
  Tooltip,
} from "recharts";
import { CheckCircle2, AlertTriangle, CloudUpload, Cpu, Database, ShieldAlert, ArrowRight } from "lucide-react";
import { demoData } from "../data/demoData";
import { C, DataCard, CardHeader, ModuleHeader, ProgressBar, SourceBadge, Badge } from "../components/shared";

const PIPELINE_STEPS = [
  { label: "原始数据采集", sub: "Telemetry · 4 采样点", icon: Database, done: true, color: C.green },
  { label: "加密传输上云", sub: "TLS 1.3 · 18ms RTT", icon: CloudUpload, done: true, color: C.cyan },
  { label: "AI 特征解析", sub: "NLP + 传感融合", icon: Cpu, done: true, color: C.blue },
  { label: "风险诊断输出", sub: "多维评分模型", icon: ShieldAlert, done: false, active: true, color: C.purple },
];

const CustomRadarTick = ({ x, y, payload }: any) => (
  <text x={x} y={y} textAnchor="middle" dominantBaseline="middle" fill={C.textSecondary} style={{ fontSize: "12px", fontWeight: 500 }}>
    {payload.value}
  </text>
);

// Move LOG_ENTRIES outside component to avoid stale closure in useEffect
const LOG_ENTRIES = [
  "[INFO] 接收批次数据包: EMS-2026-0322-A",
  "[INFO] 数据完整性校验: PASS (4/4 采样点)",
  "[WARN] Mn²⁺ 检出值: 182 mg/L (限值 2 mg/L) ↑91x",
  "[WARN] NH₃-N 检出值: 318 mg/L (限值 25 mg/L) ↑12.7x",
  "[INFO] 含水率: 25% (在控范围)",
  "[AI]  特征向量生成完毕 · dim=128",
  "[AI]  重金属风险评分: 92/100 → 高危",
  "[AI]  氨氮风险评分: 88/100 → 高危",
  "[AI]  综合风险指数: 86/100",
  "[OUT] 推荐预处理: 脱氨 · 调湿 · 分级筛分",
  "[SYS] 诊断完成 · 触发分质路由...",
];

export default function Module2() {
  const { diagnosis } = demoData;
  const [progress, setProgress] = useState(0);
  const [logLines, setLogLines] = useState<string[]>([]);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((p) => Math.min(p + 1.2, 100));
    }, 80);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    let i = 0;
    const t = setInterval(() => {
      if (i < LOG_ENTRIES.length) {
        const entry = LOG_ENTRIES[i]; // capture by value before i++ to avoid stale closure
        i++;
        setLogLines((lines) => [...lines, entry]);
      }
    }, 600);
    return () => clearInterval(t);
  }, []);

  const radarData = diagnosis.risk_dimensions.map((d) => ({
    subject: d.name,
    value: d.score,
    fullMark: 100,
  }));

  const riskColor = (score: number) =>
    score >= 80 ? C.red : score >= 60 ? C.amber : C.green;

  return (
    <div>
      <ModuleHeader
        step={2}
        title="云端中枢 · 数据同步与 AI 初始诊断"
        description="现场数据上云 → 特征解析 → 多维风险评分 → 预处理建议输出"
        accentColor={C.blue}
        statusLabel="AI 分析中"
        statusColor={C.purple}
      />

      {/* Risk Score Banner */}
      <div
        style={{
          background: "linear-gradient(135deg, rgba(239,68,68,0.1), rgba(245,158,11,0.08))",
          border: "1px solid rgba(239,68,68,0.3)",
          borderRadius: "14px",
          padding: "16px 20px",
          marginBottom: "16px",
          display: "flex",
          alignItems: "center",
          gap: "24px",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
          <AlertTriangle size={28} color={C.red} />
          <div>
            <div style={{ fontSize: "11px", fontWeight: 600, color: C.textMuted, letterSpacing: "0.08em", textTransform: "uppercase" }}>综合风险等级</div>
            <div style={{ fontSize: "28px", fontWeight: 800, color: C.red }}>{diagnosis.risk_level}风险</div>
          </div>
        </div>
        <div style={{ width: "1px", height: "40px", background: "rgba(239,68,68,0.3)" }} />
        <div>
          <div style={{ fontSize: "11px", color: C.textMuted, marginBottom: "4px" }}>综合风险指数</div>
          <div style={{ display: "flex", alignItems: "baseline", gap: "4px" }}>
            <span style={{ fontSize: "36px", fontWeight: 800, color: C.red }}>{diagnosis.risk_score}</span>
            <span style={{ fontSize: "16px", color: C.textMuted }}>/100</span>
          </div>
        </div>
        <div style={{ flex: 1 }}>
          <ProgressBar value={diagnosis.risk_score} accent={C.red} height={8} />
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: "4px" }}>
            <span style={{ fontSize: "10px", color: C.textMuted }}>低风险</span>
            <span style={{ fontSize: "10px", color: C.textMuted }}>高风险</span>
          </div>
        </div>
        <SourceBadge type={diagnosis.source_type} />
      </div>

      {/* Main 3-col Grid */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1.3fr 1fr", gap: "16px" }}>

        {/* Pipeline */}
        <DataCard>
          <CardHeader title="数据处理管线" subtitle="Data Pipeline" accent={C.blue} />
          <div style={{ padding: "16px" }}>
            {PIPELINE_STEPS.map((step, i) => {
              const Icon = step.icon;
              return (
                <div key={step.label}>
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: "12px",
                      padding: "10px 12px",
                      borderRadius: "10px",
                      background: step.active ? `${step.color}15` : step.done ? "transparent" : "transparent",
                      border: step.active ? `1px solid ${step.color}40` : "1px solid transparent",
                    }}
                  >
                    <div
                      style={{
                        width: "36px",
                        height: "36px",
                        borderRadius: "9px",
                        background: step.done || step.active ? `${step.color}20` : `${C.borderSubtle}`,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        flexShrink: 0,
                        color: step.done || step.active ? step.color : C.textMuted,
                        border: step.active ? `1px solid ${step.color}50` : "none",
                      }}
                    >
                      {step.active ? <Icon size={16} className="animate-pulse" /> : step.done ? <CheckCircle2 size={16} /> : <Icon size={16} />}
                    </div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: "13px", fontWeight: 600, color: step.done || step.active ? C.textPrimary : C.textMuted }}>
                        {step.label}
                      </div>
                      <div style={{ fontSize: "11px", color: C.textMuted }}>{step.sub}</div>
                    </div>
                    {step.done && <CheckCircle2 size={14} color={C.green} />}
                    {step.active && (
                      <div style={{ width: "6px", height: "6px", borderRadius: "50%", background: step.color }} className="animate-pulse" />
                    )}
                  </div>
                  {i < PIPELINE_STEPS.length - 1 && (
                    <div style={{ display: "flex", justifyContent: "center", height: "16px", alignItems: "center" }}>
                      <div style={{ width: "1px", height: "100%", background: i < 3 ? `${step.color}40` : C.borderSubtle }} />
                    </div>
                  )}
                </div>
              );
            })}

            {/* Progress */}
            <div style={{ marginTop: "16px", padding: "12px", background: `${C.blue}10`, borderRadius: "8px", border: `1px solid ${C.blue}20` }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "6px" }}>
                <span style={{ fontSize: "11px", color: C.textMuted }}>分析进度</span>
                <span style={{ fontSize: "11px", fontWeight: 600, color: C.blue }}>{Math.round(progress)}%</span>
              </div>
              <ProgressBar value={progress} accent={C.blue} height={5} />
            </div>

            {/* Log Terminal */}
            <div
              style={{
                marginTop: "12px",
                background: "#010812",
                borderRadius: "8px",
                border: "1px solid rgba(6,182,212,0.1)",
                padding: "8px",
                height: "130px",
                overflowY: "auto",
                fontFamily: "monospace",
              }}
            >
              {logLines.filter((line): line is string => typeof line === 'string' && Boolean(line)).map((line, i) => (
                <div
                  key={i}
                  style={{
                    fontSize: "10px",
                    color: line.startsWith("[WARN]") ? C.amber : line.startsWith("[AI]") ? C.purple : line.startsWith("[OUT]") ? C.green : "rgba(148,163,184,0.8)",
                    lineHeight: 1.6,
                  }}
                >
                  {line}
                </div>
              ))}
              {logLines.length < LOG_ENTRIES.length && (
                <div style={{ fontSize: "10px", color: C.cyan }} className="data-pulse">▌</div>
              )}
            </div>
          </div>
        </DataCard>

        {/* Radar Chart */}
        <DataCard>
          <CardHeader title="风险维度雷达" subtitle="Multi-dimension Risk Analysis" accent={C.purple} />
          <div style={{ padding: "12px 16px" }}>
            <ResponsiveContainer width="100%" height={280}>
              <RadarChart data={radarData} margin={{ top: 10, right: 30, bottom: 10, left: 30 }}>
                <PolarGrid stroke="rgba(6,182,212,0.15)" />
                <PolarAngleAxis dataKey="subject" tick={<CustomRadarTick />} />
                <Radar
                  name="风险评分"
                  dataKey="value"
                  stroke={C.red}
                  fill={C.red}
                  fillOpacity={0.2}
                  strokeWidth={2}
                  dot={{ fill: C.red, r: 4, strokeWidth: 0 }}
                />
                <Tooltip
                  contentStyle={{
                    background: C.bgCard,
                    border: `1px solid ${C.borderSubtle}`,
                    borderRadius: "8px",
                    fontSize: "12px",
                    color: C.textPrimary,
                  }}
                  formatter={(value: number) => [`${value}/100`, "风险评分"]}
                />
              </RadarChart>
            </ResponsiveContainer>

            {/* Dimension Detail */}
            <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
              {diagnosis.risk_dimensions.map((dim) => (
                <div key={dim.name} style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                  <span style={{ fontSize: "12px", color: C.textSecondary, width: "90px", flexShrink: 0 }}>{dim.name}</span>
                  <div style={{ flex: 1 }}>
                    <ProgressBar value={dim.score} accent={riskColor(dim.score)} height={4} />
                  </div>
                  <span style={{ fontSize: "12px", fontWeight: 700, color: riskColor(dim.score), width: "30px", textAlign: "right" }}>
                    {dim.score}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </DataCard>

        {/* Diagnosis & Pretreatment */}
        <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
          {/* Key Findings */}
          <DataCard glowing accent={C.red} style={{ flex: 1 }}>
            <CardHeader title="AI 诊断摘要" subtitle="Diagnosis Summary" accent={C.red} />
            <div style={{ padding: "12px 16px", display: "flex", flexDirection: "column", gap: "10px" }}>
              {[
                { label: "Mn²⁺ 超标倍数", value: "91×", color: C.red, detail: "182 vs 限值 2 mg/L" },
                { label: "NH₃-N 超标倍数", value: "12.7×", color: C.red, detail: "318 vs 限值 25 mg/L" },
                { label: "含水率状态", value: "受控", color: C.amber, detail: "25% (限值 30%)" },
                { label: "pH 值评估", value: "达标", color: C.green, detail: "6.8 (范围 6~9)" },
              ].map((item) => (
                <div
                  key={item.label}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    padding: "8px 10px",
                    background: `${item.color}0d`,
                    borderRadius: "8px",
                    border: `1px solid ${item.color}20`,
                  }}
                >
                  <div>
                    <div style={{ fontSize: "11px", color: C.textMuted }}>{item.label}</div>
                    <div style={{ fontSize: "10px", color: `${item.color}99`, marginTop: "1px" }}>{item.detail}</div>
                  </div>
                  <span style={{ fontSize: "18px", fontWeight: 800, color: item.color }}>{item.value}</span>
                </div>
              ))}
            </div>
          </DataCard>

          {/* Pretreatment */}
          <DataCard>
            <CardHeader title="预处理建议" subtitle="AI Recommended" accent={C.green} />
            <div style={{ padding: "12px 16px", display: "flex", flexDirection: "column", gap: "8px" }}>
              {diagnosis.pretreatment_advice.map((advice, i) => (
                <div
                  key={advice}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "10px",
                    padding: "10px 12px",
                    background: `${C.green}10`,
                    border: `1px solid ${C.green}25`,
                    borderRadius: "8px",
                  }}
                >
                  <div
                    style={{
                      width: "22px",
                      height: "22px",
                      borderRadius: "50%",
                      background: `${C.green}25`,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      fontSize: "11px",
                      fontWeight: 700,
                      color: C.green,
                      flexShrink: 0,
                    }}
                  >
                    {i + 1}
                  </div>
                  <span style={{ fontSize: "13px", fontWeight: 600, color: C.textPrimary }}>{advice}</span>
                  <ArrowRight size={12} color={C.green} style={{ marginLeft: "auto" }} />
                </div>
              ))}
              <div
                style={{
                  marginTop: "4px",
                  padding: "8px 10px",
                  background: "rgba(139,92,246,0.1)",
                  border: "1px solid rgba(139,92,246,0.25)",
                  borderRadius: "8px",
                }}
              >
                <div style={{ fontSize: "10px", fontWeight: 600, color: C.purple, marginBottom: "3px" }}>
                  ▸ 进入分质路由
                </div>
                <div style={{ fontSize: "11px", color: C.textMuted }}>
                  预处理完成后，AI 将匹配最优资源化方向
                </div>
              </div>
            </div>
          </DataCard>
        </div>
      </div>
    </div>
  );
}