import React from "react";
import { NavLink, Outlet, useLocation } from "react-router";
import {
  Radio,
  CloudCog,
  Brain,
  Layers,
  Network,
  Zap,
  ChevronRight,
} from "lucide-react";
import { demoData } from "../data/demoData";
import { C } from "./shared";

const navItems = [
  {
    path: "/",
    step: 1,
    label: "边缘感知",
    sublabel: "Edge Perception",
    icon: Radio,
    accent: "#06b6d4",
  },
  {
    path: "/cloud",
    step: 2,
    label: "云端中枢",
    sublabel: "Cloud Hub",
    icon: CloudCog,
    accent: "#3b82f6",
  },
  {
    path: "/ai-brain",
    step: 3,
    label: "AI 大脑",
    sublabel: "AI Engine",
    icon: Brain,
    accent: "#8b5cf6",
  },
  {
    path: "/twin",
    step: 4,
    label: "数字孪生",
    sublabel: "Digital Twin",
    icon: Layers,
    accent: "#10b981",
  },
  {
    path: "/market",
    step: 5,
    label: "商业闭环",
    sublabel: "Market Loop",
    icon: Network,
    accent: "#f59e0b",
  },
];

export function Layout() {
  const location = useLocation();
  const currentIdx = navItems.findIndex((n) =>
    n.path === "/" ? location.pathname === "/" : location.pathname?.startsWith(n.path)
  );

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        height: "100vh",
        width: "100vw",
        background: C.bgBase,
        overflow: "hidden",
        fontFamily: "'Inter', 'PingFang SC', 'Microsoft YaHei', sans-serif",
      }}
    >
      <style>{`
        @keyframes scanMove {
          0% { top: 0%; }
          100% { top: 100%; }
        }
        @keyframes dataPulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.4; }
        }
        @keyframes nodeFloat {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.15); }
        }
        .scan-anim {
          animation: scanMove 4s linear infinite;
        }
        .data-pulse {
          animation: dataPulse 2s ease-in-out infinite;
        }
        .node-float {
          animation: nodeFloat 3s ease-in-out infinite;
        }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: rgba(6,182,212,0.3); border-radius: 2px; }
      `}</style>

      {/* ── Top Header ─────────────────────────────────────────────── */}
      <header
        style={{
          height: "52px",
          background: "rgba(4,12,28,0.95)",
          borderBottom: `1px solid ${C.borderSubtle}`,
          display: "flex",
          alignItems: "center",
          padding: "0 20px",
          gap: "20px",
          backdropFilter: "blur(12px)",
          flexShrink: 0,
          zIndex: 20,
        }}
      >
        {/* Logo */}
        <div style={{ display: "flex", alignItems: "center", gap: "8px", flexShrink: 0 }}>
          <div
            style={{
              width: "28px",
              height: "28px",
              borderRadius: "7px",
              background: "linear-gradient(135deg, #06b6d4, #3b82f6)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Zap size={14} color="white" />
          </div>
          <span style={{ fontSize: "15px", fontWeight: 700, color: "#e2e8f0", letterSpacing: "-0.02em" }}>
            AIizer
          </span>
          <span
            style={{
              fontSize: "10px",
              fontWeight: 500,
              color: "#06b6d4",
              background: "rgba(6,182,212,0.12)",
              border: "1px solid rgba(6,182,212,0.3)",
              borderRadius: "4px",
              padding: "1px 6px",
            }}
          >
            {demoData.project.version}
          </span>
        </div>

        <div style={{ width: "1px", height: "20px", background: C.borderSubtle }} />

        {/* Batch Info */}
        <div style={{ display: "flex", alignItems: "center", gap: "16px", flex: 1 }}>
          <div>
            <span style={{ fontSize: "10px", fontWeight: 500, color: C.textMuted, textTransform: "uppercase", letterSpacing: "0.08em" }}>
              Batch ID
            </span>
            <div style={{ fontSize: "13px", fontWeight: 600, color: "#06b6d4", letterSpacing: "0.04em" }}>
              {demoData.batch.batch_id}
            </div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: "5px" }}>
            <div style={{ width: "6px", height: "6px", borderRadius: "50%", background: "#10b981" }} className="animate-pulse" />
            <span style={{ fontSize: "12px", fontWeight: 500, color: C.textSecondary }}>
              {demoData.batch.site_name}
            </span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
            <span style={{ fontSize: "11px", color: C.textMuted }}>N {demoData.batch.lat}° · E {demoData.batch.lng}°</span>
          </div>
          <div
            style={{
              padding: "3px 10px",
              background: "rgba(16,185,129,0.12)",
              border: "1px solid rgba(16,185,129,0.3)",
              borderRadius: "20px",
              fontSize: "12px",
              fontWeight: 600,
              color: "#10b981",
            }}
          >
            {demoData.batch.total_quantity_tons.toLocaleString()} 吨
          </div>
        </div>

        {/* Journey flow indicator */}
        <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
          {navItems.map((item, i) => (
            <React.Fragment key={item.step}>
              <div
                style={{
                  width: "22px",
                  height: "22px",
                  borderRadius: "50%",
                  background: i <= currentIdx ? `${item.accent}30` : "transparent",
                  border: `1px solid ${i <= currentIdx ? item.accent : C.borderSubtle}`,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: "10px",
                  fontWeight: 700,
                  color: i <= currentIdx ? item.accent : C.textMuted,
                  transition: "all 0.3s ease",
                }}
              >
                {item.step}
              </div>
              {i < navItems.length - 1 && (
                <ChevronRight size={10} color={i < currentIdx ? item.accent : C.borderSubtle} />
              )}
            </React.Fragment>
          ))}
        </div>

        <div style={{ width: "1px", height: "20px", background: C.borderSubtle }} />

        <div style={{ display: "flex", alignItems: "center", gap: "6px", flexShrink: 0 }}>
          <div style={{ width: "6px", height: "6px", borderRadius: "50%", background: "#06b6d4" }} className="animate-pulse" />
          <span style={{ fontSize: "11px", fontWeight: 500, color: C.textSecondary }}>
            {demoData.project.last_updated}
          </span>
        </div>
      </header>

      {/* ── Body ───────────────────────────────────────────────────── */}
      <div style={{ display: "flex", flex: 1, overflow: "hidden" }}>
        {/* Sidebar */}
        <aside
          style={{
            width: "200px",
            flexShrink: 0,
            background: "rgba(4,12,28,0.8)",
            borderRight: `1px solid ${C.borderSubtle}`,
            display: "flex",
            flexDirection: "column",
            padding: "16px 0",
            gap: "4px",
          }}
        >
          <div style={{ padding: "0 12px 12px", borderBottom: `1px solid ${C.borderSubtle}`, marginBottom: "8px" }}>
            <div style={{ fontSize: "10px", fontWeight: 600, color: C.textMuted, letterSpacing: "0.1em", textTransform: "uppercase" }}>
              处理流程
            </div>
          </div>

          {navItems.map((item, i) => {
            const Icon = item.icon;
            const isActive =
              item.path === "/"
                ? location.pathname === "/"
                : location.pathname?.startsWith(item.path) ?? false;
            const isPast = i < currentIdx;

            return (
              <NavLink
                key={item.path}
                to={item.path}
                style={{ textDecoration: "none" }}
              >
                <div
                  style={{
                    margin: "0 10px",
                    borderRadius: "10px",
                    padding: "10px 12px",
                    display: "flex",
                    alignItems: "center",
                    gap: "10px",
                    background: isActive ? `${item.accent}18` : "transparent",
                    border: isActive ? `1px solid ${item.accent}40` : "1px solid transparent",
                    cursor: "pointer",
                    transition: "all 0.2s ease",
                    position: "relative",
                  }}
                >
                  {isActive && (
                    <div
                      style={{
                        position: "absolute",
                        left: 0,
                        top: "50%",
                        transform: "translateY(-50%)",
                        width: "3px",
                        height: "20px",
                        background: item.accent,
                        borderRadius: "0 2px 2px 0",
                      }}
                    />
                  )}
                  <div
                    style={{
                      width: "28px",
                      height: "28px",
                      borderRadius: "7px",
                      background: isActive ? `${item.accent}25` : isPast ? `${item.accent}15` : `${C.borderSubtle}`,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      flexShrink: 0,
                      color: isActive ? item.accent : isPast ? `${item.accent}90` : C.textMuted,
                    }}
                  >
                    <Icon size={14} />
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: "13px", fontWeight: isActive ? 600 : 500, color: isActive ? item.accent : isPast ? C.textSecondary : C.textMuted }}>
                      {item.label}
                    </div>
                    <div style={{ fontSize: "10px", color: C.textMuted }}>{item.sublabel}</div>
                  </div>
                  <div
                    style={{
                      fontSize: "10px",
                      fontWeight: 700,
                      color: isActive ? item.accent : C.textMuted,
                      opacity: 0.6,
                    }}
                  >
                    {String(item.step).padStart(2, "0")}
                  </div>
                </div>

                {/* Connector */}
                {i < navItems.length - 1 && (
                  <div
                    style={{
                      margin: "2px auto",
                      width: "1px",
                      height: "12px",
                      background: isPast || isActive ? `${item.accent}50` : C.borderSubtle,
                    }}
                  />
                )}
              </NavLink>
            );
          })}

          <div style={{ flex: 1 }} />

          {/* Bottom: demo note */}
          <div
            style={{
              margin: "0 10px",
              padding: "10px 12px",
              background: "rgba(245,158,11,0.08)",
              border: "1px solid rgba(245,158,11,0.2)",
              borderRadius: "10px",
            }}
          >
            <div style={{ fontSize: "10px", fontWeight: 600, color: "#f59e0b", marginBottom: "4px" }}>
              Demo 模式
            </div>
            <div style={{ fontSize: "10px", color: C.textMuted, lineHeight: 1.5 }}>
              部分数据基于演示假设，标注来源可查
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main
          style={{
            flex: 1,
            overflowY: "auto",
            overflowX: "hidden",
            padding: "24px",
            background: C.bgBase,
          }}
        >
          <Outlet />
        </main>
      </div>
    </div>
  );
}